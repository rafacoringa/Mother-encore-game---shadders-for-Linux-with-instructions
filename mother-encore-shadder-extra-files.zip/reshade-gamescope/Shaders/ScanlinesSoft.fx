#include "ReShade.fxh"

uniform float LineStrength <
    ui_type = "slider";
    ui_min = 0.0;
    ui_max = 0.6;
    ui_label = "Scanline Strength";
> = 0.16;

uniform float LineSpacing <
    ui_type = "slider";
    ui_min = 1.0;
    ui_max = 4.0;
    ui_label = "Scanline Spacing";
> = 2.0;

float4 ScanlinesPS(float4 pos : SV_Position, float2 texcoord : TEXCOORD) : SV_Target
{
    float4 color = tex2D(ReShade::BackBuffer, texcoord);

    float y = texcoord.y * ReShade::ScreenSize.y;
    float line = fmod(floor(y / LineSpacing), 2.0);

    float brightness = lerp(1.0, 1.0 - LineStrength, line);

    color.rgb *= brightness;
    return color;
}

technique ScanlinesSoft
{
    pass
    {
        VertexShader = PostProcessVS;
        PixelShader = ScanlinesPS;
    }
}
