#!/usr/bin/env bash

cd "$HOME/Games" || exit 1

unset DRI_PRIME

# Garante que a versão editada do shader esteja onde o gamescope procura
mkdir -p "$HOME/.local/share/gamescope/reshade/Shaders"
cp "$HOME/Games/reshade-gamescope/Shaders/NostalgiaNoNES.fx" \
   "$HOME/.local/share/gamescope/reshade/Shaders/NostalgiaNoNES.fx"

gamescope -W 1600 -H 900 -w 1600 -h 900 -r 60 -S integer -F pixel \
  --reshade-effect NostalgiaNoNES.fx \
  --reshade-technique-idx 0 \
  -- ./MotherEncore4.0.1.x86_64
EOF
