#!/usr/bin/env bash

cd "$HOME/Games" || exit 1

unset DRI_PRIME

gamescope -W 1600 -H 900 -w 1600 -h 900 -r 60 -S integer -F pixel \
  --reshade-effect Nostalgia.fx \
  --reshade-technique-idx 0 \
  -- ./MotherEncore4.0.1.x86_64
EOF
